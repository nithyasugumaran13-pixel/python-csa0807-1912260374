"""Compare totals and timings; measured values depend on the computer."""
from decimal import Decimal
from time import perf_counter

PAYMENT_TEXT = "33.40"

def total_float(items):
    """Sum strings as floats."""
    total = 0.0
    for item in items:
        total += float(item)
    return total

def total_decimal(items):
    """Sum strings as exact Decimal values."""
    total = Decimal("0.00")
    for item in items:
        total += Decimal(item)
    return total

def measure(function, values):
    """Return result and elapsed seconds."""
    start = perf_counter()
    result = function(values)
    return result, perf_counter() - start

if __name__ == "__main__":
    for n in (300, 6000, 150000):
        values = [PAYMENT_TEXT] * n
        f_total, f_time = measure(total_float, values)
        d_total, d_time = measure(total_decimal, values)
        print(f"n={n:6} float={f_total:.12f} ({f_time:.6f}s)")
        print(f"       Decimal={d_total} ({d_time:.6f}s)")
        print(f"       difference (float - Decimal) = {Decimal(str(f_total)) - d_total}")
