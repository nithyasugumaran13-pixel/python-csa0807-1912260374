# Task 8 — Pseudocode and trace

## Pseudocode
BEGIN
  SET ten_day_total = 0
  FOR each milk entry
    READ farmer_id, litres, fat, snf, shift
    IF any field is invalid THEN
      DISPLAY validation error
      request correction
    ELSE
      fat_steps = nearest whole step((fat - 3.5) / 0.1)
      snf_steps = nearest whole step((snf - 8.5) / 0.1)
      rate = round-to-paise(30 + fat_steps*0.40 + snf_steps*0.30)
      payment = round-to-paise(litres * rate)
      ten_day_total = ten_day_total + payment
      DISPLAY payment
    END IF
  END FOR
  DISPLAY ten_day_total
END

## Hand trace
| Entry | Litres | Fat | SNF | Rate (Rs/L) | Payment (Rs) |
|---|---:|---:|---:|---:|---:|
| 1 | 10 | 3.5 | 8.5 | 30.00 | 300.00 |
| 2 | 8.5 | 4.2 | 8.7 | 33.40 | 283.90 |
| 3 | 12 | 3.1 | 8.3 | 27.80 | 333.60 |
| **Total** | | | | | **917.50** |
