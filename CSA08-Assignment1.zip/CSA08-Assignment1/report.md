# Assignment Report: Ksheera Village Milk Co-operative Payment Calculator

**Name:** TODO  
**Register number:** TODO  
**Repository link:** TODO  
**Python version:** TODO (copy the result of `python --version`)

> Learning note: This is a worked starter report. Run the programs yourself, add genuine screenshots, record your own measurements, and make sure you can explain the code before submitting.

## Task 1 — Understand the problem and identify the data
- **Inputs:** farmer ID (text, because identifiers may contain letters/leading zeroes), litres (fractional numeric value), fat % and SNF % (fractional readings), shift (text or a small integer category), and the ten-day period.
- **Outputs:** fat/SNF step counts, rate per litre, payment for each accepted entry, and ten-day total per farmer.
- **Constants:** base rate Rs 30.00, reference fat 3.5%, reference SNF 8.5%, fat adjustment Rs 0.40 per 0.1 percentage-point step, SNF adjustment Rs 0.30 per step, and permitted fat range 2.0%–7.0%. Constants prevent rate changes from being missed in multiple expressions.
- **Types:** farmer ID/shift are strings; litres, fat and SNF are decimal quantities; step counts are integers; money should use `Decimal` or integer paise to avoid binary-float accumulation errors.
- **Rules:** litres must be non-negative; fat must be 2.0–7.0 inclusive; SNF must be checked against the cooperative's official accepted range (the supplied scenario does not specify one, so this project uses a documented provisional range of 0.0–15.0); shift must be one of the accepted labels; reject non-numeric text; round the calculated rate and payment to two decimal places according to the declared policy.
- **Assumptions:** rate adjustment is per nearest 0.1 percentage-point step from the reference value; payments are rounded per entry to the nearest paisa. Confirm these assumptions with faculty if a different rule is required.
- **Alternative concept:** Separate variables such as `litres1`, `fat1`, `snf1` do not scale well and make loops/reports awkward. A list of records lets one loop process n entries in O(n) time; storing n records costs O(n) space. Separate variables are still O(n) in a broad count, but code grows with each farmer and cannot naturally process arbitrary n.

## Task 2 — Explore values and types in the interpreter
Try these in IDLE's `>>>` prompt:
```py
type(10)                 # int
type(10.0)               # float
type("10")               # str
type(True)               # bool
type([10, 8.5])          # list
7 / 2                    # 3.5
7 // 2                   # 3
7 % 2                    # 1
-7 // 2                  # -4, floor division rounds down
0.1 + 0.2 == 0.3         # False, binary floating-point approximation
```
`Decimal("0.1") + Decimal("0.2") == Decimal("0.3")` is `True`. `Decimal` constructed from a string preserves the intended decimal value; constructing it from a float imports the float's approximation. Integer paise is another exact option if all amounts are rounded to paise. `round()` does not make every float operation exact.

The completed TODO program is in `Task02/decimal_totals.py`. Run it and compare with the expected output in `Task02/expected_output.txt`.

## Task 3 — Variables and constants
`Task03/constants.py` uses uppercase names for constants. Python does not enforce constants; uppercase is a convention. Dynamic typing allows a name to refer first to an integer and later to a string, but changing a value's type unexpectedly can cause bugs. `a, b = b, a` swaps values without a temporary variable. If magic numbers occur in k places, a rate revision may require k edits; constants require one edit. Runtime and asymptotic memory remain O(1).

## Task 4 — Correct expressions
The reusable expression is `round((fat - REFERENCE_FAT) / 0.1)` for fat steps, with the corresponding SNF expression. Binary float can represent values such as 4.2 and 0.1 only approximately, so an apparent 7-step result may be `7.000000000000001`. `round()` helps convert the intended step count to an integer, but business rounding policy should be explicit. `int()` truncates toward zero; `math.floor()` rounds toward negative infinity; `round()` uses ties-to-even for exact halfway cases. For fat 4.2, raw steps are near 7; for fat 3.1, raw steps are near -4. Using `int()` on a negative value such as -3.999... may produce -3, while `floor()` produces -4. See `Task04/expressions.py`.

## Task 5 — Input and type conversion
`input()` returns text. Convert numeric fields only after validation; `float(" 8.5 ")` accepts surrounding whitespace, while `"8,5"` and `"eight"` raise `ValueError`. `try/except ValueError` is clearer and more reliable than attempting to validate every possible numeric string manually. Use f-strings such as `f"{amount:8.2f}"` for aligned two-decimal output. See `Task05/input_demo.py`.

## Task 6 — Functions
`Task06/payment_functions.py` separates `rate_per_litre`, `payout`, and `ten_day_total`; each function has parameters, a return value, and a docstring. Returning a value lets other functions test, reuse, or combine it; printing is only display. Function calls have a small constant overhead, so total work remains O(n) for n entries. Functions reduce repeated code and make testing easier.

## Task 7 — Module
`Task07/milkrate.py` is the reusable module; `Task07/test_module.py` imports and calls it. `import milkrate as mr` uses the alias `mr`; `from milkrate import payout` imports the name directly. The `if __name__ == "__main__":` block runs only when the file is executed directly, not when imported, so importing the module does not print the demonstration table. Python searches the current script directory and paths in `sys.path`.

## Task 8 — Algorithm plan
**Pseudocode**
1. Set ten-day total to Decimal zero.
2. For each entry, read farmer ID, litres, fat, SNF and shift.
3. Validate every field; if invalid, report the error and request correction.
4. Calculate nearest fat and SNF step counts.
5. Calculate and round the rate per litre.
6. Multiply litres by rate and round payment to paise.
7. Add payment to ten-day total.
8. Display each payment and the final total.

Flowchart source is in `Task08/validation_flowchart.mmd`. For n entries, processing is O(n). Storing all entries costs O(n) space; a running total alone uses O(1) extra space, but storing records is useful for audit, corrections and reports.

Hand trace (reference fat 3.5, SNF 8.5): 10 L at (3.5, 8.5) → rate 30.00, pay 300.00; 8.5 L at (4.2, 8.7) → rate 33.40, pay 283.90; 12 L at (3.1, 8.3) → rate 27.80, pay 333.60. Total = Rs 917.50.

## Task 9 — Implement and test
`Task09/calculator.py` validates inputs and calculates payment. `Task09/test_calculator.py` contains assertions for normal and boundary cases. Run both programs. Add a test table with your actual results and screenshots. Automated assertions are faster to repeat after changes than manually retyping each case.

## Task 10 — Expected versus execution
Run `Task10/benchmark.py` to measure float and Decimal totals for 300, 6,000 and 150,000 entries with `time.perf_counter()`. Copy the actual times and differences into this report. Do not claim measurements before running them: results depend on the computer and Python version. The expected mathematical amount and the measured floating-point amount can differ by tiny fractions of a rupee. Round each payable entry to paise when that matches the bank's payment policy; rounding only the final aggregate can produce a different result.

## Task 11 — Final recommendation
Recommend a single rate module, named constants, input validation, and `Decimal` values created from strings for monetary arithmetic. Define whether rates and individual payouts are rounded before aggregation, and test that policy against the cooperative's bank statement. A module makes rate changes centralised. At district scale, O(n) processing of 150,000 records is practical for a simple calculation, but persistent storage, audit logs, duplicate-entry protection, access controls, and reconciliation would be needed in a production system. A JSON rate card can make seasonal changes configurable but must be validated and version-controlled.

## Task 12 — Seasonal design challenge
The new requirement changes the base rate from April through June to Rs 32.00, fat-step value to Rs 0.45, adds two-decimal analyser readings, and grants Rs 0.50 per litre when ten-day volume exceeds 500 L. `Task12/seasonal_calculator.py` passes the season/rate card as data, uses Decimal string conversions, and separates the bonus from the per-litre rate. Test both standard and seasonal cases, including exactly 500 L (no bonus) and more than 500 L (bonus). This is a **modify** decision: retain the modular calculation, but change rate-card selection and bonus handling. Add the actual run output and screenshots before submission.

## Complexity summary
- One payment: O(1) time and O(1) extra space.
- n payments: O(n) time.
- Storing n entries: O(n) space; running total without retaining entries: O(1) extra space.
- Cached rate lookup for k distinct (fat, SNF) pairs: expected O(1) dictionary lookup per entry, with O(k) extra space; measure before optimising.
