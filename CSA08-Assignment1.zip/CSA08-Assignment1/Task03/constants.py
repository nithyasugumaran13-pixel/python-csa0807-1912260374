"""Named constants and basic Python naming demonstrations."""
BASE_RATE = 30.00
REFERENCE_FAT = 3.5
REFERENCE_SNF = 8.5
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STEP_PERCENT = 0.1
MIN_FAT = 2.0
MAX_FAT = 7.0

if __name__ == "__main__":
    print("Base rate:", BASE_RATE)
    print("Fat range:", MIN_FAT, "to", MAX_FAT)
    value = 10
    print(value, type(value))
    value = "ten"
    print(value, type(value))
    a, b = 1, 2
    a, b = b, a
    print("Swapped:", a, b)
