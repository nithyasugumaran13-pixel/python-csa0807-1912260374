# Task 11 — Final design recommendation

Recommend `Decimal` created from text for money-sensitive calculations, a single module for the rate card, explicit input validation, and a documented rounding rule. Store entries as records with farmer ID, date/period, shift, litres, fat, SNF, rate and rounded payout. Test with the bank's expected totals before deployment.

A rate revision should change the central rate card or a validated configuration file, not repeated expressions. The simple calculator is O(n) for n entries and should be adequate for 150,000 entries, but production use also needs durable records, audit history, duplicate detection, access control, backup, error logging and reconciliation. Reading a JSON rate card adds O(k) startup work and O(k) storage for k configuration values, but makes revisions easier without editing program logic. Configuration must be validated and changes audited.
