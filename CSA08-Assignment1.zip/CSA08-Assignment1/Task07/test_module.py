"""Separate script showing how to import and call milkrate."""
import milkrate as mr

if __name__ == "__main__":
    print("Imported module:", mr.__file__)
    print("Rate:", mr.rate_per_litre(4.2, 8.7))
    print("Payout:", mr.payout(8.5, 4.2, 8.7))
