"""Rate card of the village milk co-operative (used as a module)."""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
REFERENCE_FAT = Decimal("3.5")
REFERENCE_SNF = Decimal("8.5")
STEP_PERCENT = Decimal("0.1")
PAISE = Decimal("0.01")

def _steps(value, reference):
    """Count nearest 0.1 percentage-point steps from a reference."""
    return int(((Decimal(str(value)) - reference) / STEP_PERCENT).quantize(Decimal("1"), rounding=ROUND_HALF_UP))

def rate_per_litre(fat, snf):
    """Return the price per litre, rounded to two decimals."""
    fat_steps = _steps(fat, REFERENCE_FAT)
    snf_steps = _steps(snf, REFERENCE_SNF)
    rate = BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE
    return rate.quantize(PAISE, rounding=ROUND_HALF_UP)

def payout(litres, fat, snf):
    """Return the amount payable, rounded to two decimals."""
    amount = Decimal(str(litres)) * rate_per_litre(fat, snf)
    return amount.quantize(PAISE, rounding=ROUND_HALF_UP)

if __name__ == "__main__":
    for litres, fat, snf in [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]:
        rate = rate_per_litre(fat, snf)
        pay = payout(litres, fat, snf)
        print(f"{litres:5} L  fat {fat}  snf {snf}  rate {rate:6.2f}  pay {pay:8.2f}")
