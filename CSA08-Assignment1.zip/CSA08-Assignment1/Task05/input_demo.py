"""Safe conversion of text input and formatted output."""
def read_number(prompt):
    """Read a float, repeating the prompt until conversion succeeds."""
    while True:
        text = input(prompt).strip()
        try:
            return float(text)
        except ValueError:
            print("Please enter a number using a decimal point, e.g. 8.5.")

if __name__ == "__main__":
    litres = read_number("Enter litres: ")
    amount = read_number("Enter amount in rupees: ")
    print(f"Litres: {litres:8.2f}")
    print(f"Amount: Rs {amount:8.2f}")
