# Ksheera Village Milk Co-operative — Payment Calculator

**Student name:** TODO — enter your name  
**Register number:** TODO — enter your register number  
**Python version:** Python 3.10+ (record the exact version installed on your computer)

## Project structure
Each `TaskXX` folder contains the relevant Python source and supporting notes. Run each program from a terminal or Python IDLE. For example:

```bash
python Task07/milkrate.py
python Task07/test_module.py
python Task09/calculator.py
python Task09/test_calculator.py
python Task10/benchmark.py
python Task12/seasonal_calculator.py
```

In IDLE, open the `.py` file and choose **Run → Run Module**.

## Libraries
The core calculator uses the Python standard library only (`decimal`, `time`, `sys`, `json`, `unittest`). No third-party libraries are required. See `requirements.txt`.

## Task result notes
- **Task 1:** Analyses inputs, outputs, constants, validation rules, assumptions, and alternative data structures.
- **Task 2:** Explores interpreter types/operators and compares float accumulation with `Decimal`.
- **Task 3:** Defines named rate and validation constants.
- **Task 4:** Demonstrates rate-step expressions and floating-point surprises.
- **Task 5:** Validates text input using conversion and `try/except`.
- **Task 6:** Organises calculations into documented functions.
- **Task 7:** Provides the reusable `milkrate` module and a separate import demonstration.
- **Task 8:** Provides pseudocode, a flowchart (Mermaid source), and a hand trace.
- **Task 9:** Implements validation and automated tests.
- **Task 10:** Measures float versus Decimal totals and execution times at different sizes.
- **Task 11:** Recommends a final design with limitations and scale discussion.
- **Task 12:** Implements seasonal rates, two-decimal analyser readings, and the ten-day volume bonus.

## Evidence you must add yourself
The assignment requires proof that you individually executed every task. Run each program on your computer and save genuine screenshots of the Python Shell/terminal output inside the matching task folder. Do not use the sample expected-output text as a substitute for screenshots. Fill in your name, register number, actual Python version, and measured results in `report.md`.

## GitHub
Create a repository named `CSA08-<RegisterNumber>-Assignment1`, replacing the placeholder with your actual register number. Add this folder's contents, commit progressively (at least one meaningful commit per task), and share the repository with faculty according to your course instructions. Do not publish your register number publicly if your institution requires a private repository.
