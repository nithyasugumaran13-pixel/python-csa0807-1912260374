# Task 12 test plan and worked examples

Run `python seasonal_calculator.py` and save genuine screenshots.

- February, 10 L at 3.50% fat and 8.50% SNF: normal base rate Rs 30.00/L, total Rs 300.00.
- April, 10 L at 3.52% fat and 8.49% SNF: nearest-step rule yields fat 0 steps and SNF 0 steps, so seasonal rate Rs 32.00/L and total Rs 320.00.
- Exactly 500 L in April at reference readings: bonus does not apply because the rule says **more than** 500 L; total Rs 16,000.00.
- 501 L in April at reference readings: base payment Rs 16,032.00 plus bonus Rs 250.50 = Rs 16,282.50.

The brief does not explicitly state whether the bonus is applied to all litres once the threshold is exceeded or only to litres above 500. This implementation applies it to all litres when total ten-day volume exceeds 500 L. Confirm this interpretation with faculty.
