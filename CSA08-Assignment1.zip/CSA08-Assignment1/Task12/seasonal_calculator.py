"""Seasonal rate calculator with two-decimal readings and ten-day bonus."""
from decimal import Decimal, ROUND_HALF_UP

PAISE = Decimal("0.01")
STEP = Decimal("0.1")
REFERENCE_FAT = Decimal("3.5")
REFERENCE_SNF = Decimal("8.5")
NORMAL_CARD = {
    "base": Decimal("30.00"),
    "fat_step": Decimal("0.40"),
    "snf_step": Decimal("0.30"),
}
SEASONAL_CARD = {
    "base": Decimal("32.00"),
    "fat_step": Decimal("0.45"),
    "snf_step": Decimal("0.30"),  # unchanged by the brief
}
BONUS_PER_LITRE = Decimal("0.50")
BONUS_THRESHOLD = Decimal("500.00")

def dec(value):
    """Convert a reading or amount through its string representation."""
    return Decimal(str(value))

def round_money(value):
    """Round a rupee amount to paise using half-up rounding."""
    return value.quantize(PAISE, rounding=ROUND_HALF_UP)

def select_rate_card(month):
    """Return the seasonal card for April–June, otherwise normal rates."""
    if month in (4, 5, 6, "April", "May", "June", "april", "may", "june"):
        return SEASONAL_CARD
    return NORMAL_CARD

def rate_per_litre(fat, snf, month):
    """Calculate the rate for readings that may contain two decimal places."""
    card = select_rate_card(month)
    fat_steps = int(((dec(fat) - REFERENCE_FAT) / STEP).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    snf_steps = int(((dec(snf) - REFERENCE_SNF) / STEP).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    rate = card["base"] + fat_steps * card["fat_step"] + snf_steps * card["snf_step"]
    return round_money(rate)

def ten_day_payment(entries, month):
    """Return (total litres, total payout) for entries (litres, fat, snf)."""
    total_litres = sum((dec(row[0]) for row in entries), Decimal("0"))
    total = Decimal("0.00")
    for litres, fat, snf in entries:
        entry_payment = round_money(dec(litres) * rate_per_litre(fat, snf, month))
        total += entry_payment
    if total_litres > BONUS_THRESHOLD:
        total += round_money(total_litres * BONUS_PER_LITRE)
    return total_litres, round_money(total)

if __name__ == "__main__":
    cases = [
        ("normal month", 2, [(10, "3.50", "8.50")]),
        ("seasonal month", 4, [(10, "3.52", "8.49")]),
        ("exactly 500 L: no bonus", 4, [(500, "3.50", "8.50")]),
        ("over 500 L: bonus", 4, [(501, "3.50", "8.50")]),
    ]
    for label, month, entries in cases:
        litres, amount = ten_day_payment(entries, month)
        print(f"{label}: month={month}, litres={litres}, total=Rs {amount:.2f}")
