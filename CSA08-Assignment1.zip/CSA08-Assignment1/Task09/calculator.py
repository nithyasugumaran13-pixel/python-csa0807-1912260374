"""Validated one-entry milk payment calculator."""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
REFERENCE_FAT = Decimal("3.5")
REFERENCE_SNF = Decimal("8.5")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
STEP_PERCENT = Decimal("0.1")
PAISE = Decimal("0.01")
MIN_FAT = Decimal("2.0")
MAX_FAT = Decimal("7.0")
MIN_SNF = Decimal("0.0")   # Provisional; confirm official cooperative rule.
MAX_SNF = Decimal("15.0") # Provisional; confirm official cooperative rule.

def as_decimal(value):
    """Convert user-supplied values through text to avoid importing float noise."""
    return Decimal(str(value))

def rate_per_litre(fat, snf):
    """Calculate and return a rate rounded to paise."""
    fat_steps = int(((as_decimal(fat) - REFERENCE_FAT) / STEP_PERCENT).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    snf_steps = int(((as_decimal(snf) - REFERENCE_SNF) / STEP_PERCENT).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return (BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE).quantize(PAISE, rounding=ROUND_HALF_UP)

def payout(litres, fat, snf):
    """Validate an entry and return (rate, rounded payment)."""
    litres, fat, snf = as_decimal(litres), as_decimal(fat), as_decimal(snf)
    if litres < 0:
        raise ValueError("litres cannot be negative")
    if not MIN_FAT <= fat <= MAX_FAT:
        raise ValueError("fat must be between 2.0 and 7.0 inclusive")
    if not MIN_SNF <= snf <= MAX_SNF:
        raise ValueError("SNF is outside the provisional 0.0–15.0 range")
    rate = rate_per_litre(fat, snf)
    amount = (litres * rate).quantize(PAISE, rounding=ROUND_HALF_UP)
    return rate, amount

if __name__ == "__main__":
    farmer_id = input("Farmer ID: ").strip()
    try:
        litres = input("Litres: ").strip()
        fat = input("Fat %: ").strip()
        snf = input("SNF %: ").strip()
        rate, amount = payout(litres, fat, snf)
        print(f"Farmer: {farmer_id}")
        print(f"Rate: Rs {rate:6.2f}/L")
        print(f"Payment: Rs {amount:8.2f}")
    except Exception as exc:
        print("Entry rejected:", exc)
