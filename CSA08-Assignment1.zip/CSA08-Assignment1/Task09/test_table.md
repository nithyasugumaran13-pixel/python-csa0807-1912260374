# Test table template

Run `python test_calculator.py` and `python calculator.py`. Record your actual output/screenshot.

| Test | Input | Expected result | Actual result |
|---|---|---|---|
| Standard | 10 L, fat 3.5, SNF 8.5 | Rs 30.00/L, Rs 300.00 | TODO |
| Above standard | 8.5 L, fat 4.2, SNF 8.7 | Rs 33.40/L, Rs 283.90 | TODO |
| Below standard | 12 L, fat 3.1, SNF 8.3 | Rs 27.80/L, Rs 333.60 | TODO |
| Minimum fat | fat 2.0, SNF 8.5 | Rs 24.00/L | TODO |
| Maximum fat | fat 7.0, SNF 8.5 | Rs 44.00/L | TODO |
| Negative litres | -1 L | Rejected | TODO |
| Invalid text | "eight" litres | Rejected | TODO |
| Fat too low | 1.9% | Rejected | TODO |
| Fat too high | 7.1% | Rejected | TODO |
