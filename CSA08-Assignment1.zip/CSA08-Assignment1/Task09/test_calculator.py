"""Automated checks for calculator.py."""
from decimal import Decimal
from calculator import payout, rate_per_litre

def run_tests():
    assert payout(10, 3.5, 8.5) == (Decimal("30.00"), Decimal("300.00"))
    assert payout("8.5", "4.2", "8.7") == (Decimal("33.40"), Decimal("283.90"))
    assert payout(12, 3.1, 8.3) == (Decimal("27.80"), Decimal("333.60"))
    assert rate_per_litre(2.0, 8.5) == Decimal("24.00")
    assert rate_per_litre(7.0, 8.5) == Decimal("44.00")
    for values in [(-1, 3.5, 8.5), (1, 1.9, 8.5), (1, 7.1, 8.5), ("eight", 3.5, 8.5)]:
        try:
            payout(*values)
        except (ValueError, ArithmeticError):
            pass
        else:
            raise AssertionError(f"Expected invalid entry to be rejected: {values}")
    print("All calculator tests passed.")

if __name__ == "__main__":
    run_tests()
