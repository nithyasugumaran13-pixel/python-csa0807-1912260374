"""Demonstrate rate-step expressions and common surprises."""
import math

REFERENCE_FAT = 3.5
REFERENCE_SNF = 8.5
STEP_PERCENT = 0.1
BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30

def show_steps(fat, snf):
    """Return nearest whole fat/SNF step counts."""
    fat_steps = round((fat - REFERENCE_FAT) / STEP_PERCENT)
    snf_steps = round((snf - REFERENCE_SNF) / STEP_PERCENT)
    rate = round(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE, 2)
    return fat_steps, snf_steps, rate

if __name__ == "__main__":
    print("(4.2 - 3.5) / 0.1 =", (4.2 - 3.5) / 0.1)
    print("0.1 + 0.2 =", 0.1 + 0.2)
    print("round(2.5) and round(3.5) =", round(2.5), round(3.5), "(ties-to-even)")
    print("int(-3.9), floor(-3.9), round(-3.9) =", int(-3.9), math.floor(-3.9), round(-3.9))
    print("fat 4.2:", show_steps(4.2, 8.5))
    print("fat 3.1:", show_steps(3.1, 8.5))
