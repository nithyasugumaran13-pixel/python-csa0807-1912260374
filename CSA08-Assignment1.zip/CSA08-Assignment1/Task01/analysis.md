# Task 1 — Problem analysis

## Inputs and outputs
- `farmer_id`: `str`; identifiers are labels, not quantities, and may contain leading zeroes.
- `litres`: non-negative decimal quantity; fractional litres may be reported.
- `fat_percent`, `snf_percent`: decimal readings; fat must be between 2.0 and 7.0 inclusive.
- `shift`: `"morning"` or `"evening"` (stored as text).
- Outputs: step counts, rate per litre, entry payment, and ten-day total per farmer.

## Constants
Base rate Rs 30.00; reference fat 3.5%; reference SNF 8.5%; fat adjustment Rs 0.40 per 0.1 percentage-point; SNF adjustment Rs 0.30 per 0.1 percentage-point. Store these in one rate card so a revision has one source of truth.

## Validation and assumptions
Reject negative litres and non-numeric values. Fat range is 2.0–7.0 inclusive. The brief does not give an SNF limit; confirm the accepted range with the co-operative. For demonstrations in this project, SNF is provisionally limited to 0–15%. Use nearest whole 0.1 percentage-point steps and round each payment to two decimal places. Confirm rounding policy with faculty.

## Alternative structure and complexity
For 300 farmers, individually named variables (`litres1`, `fat1`, `snf1`, etc.) create repetitive code and cannot easily handle a changed number of farmers. A list of records can be looped over: O(n) time to process n entries, O(n) storage when all records are retained. A running total uses O(1) extra space but loses per-entry records unless they are stored elsewhere.
