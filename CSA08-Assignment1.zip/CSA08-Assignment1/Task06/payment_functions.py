"""Reusable functions for calculating milk payment."""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
REFERENCE_FAT = Decimal("3.5")
REFERENCE_SNF = Decimal("8.5")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
STEP_PERCENT = Decimal("0.1")
PAISE = Decimal("0.01")

def money(value):
    """Round a rupee amount to two decimal places."""
    return Decimal(value).quantize(PAISE, rounding=ROUND_HALF_UP)

def nearest_step(reading, reference):
    """Return the nearest whole 0.1 percentage-point step."""
    return int(((Decimal(str(reading)) - reference) / STEP_PERCENT).quantize(Decimal("1"), rounding=ROUND_HALF_UP))

def rate_per_litre(fat, snf):
    """Return the calculated rate per litre, rounded to paise."""
    fat_steps = nearest_step(fat, REFERENCE_FAT)
    snf_steps = nearest_step(snf, REFERENCE_SNF)
    return money(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE)

def payout(litres, fat, snf):
    """Return the rounded payment for one milk entry."""
    return money(Decimal(str(litres)) * rate_per_litre(fat, snf))

def ten_day_total(payments):
    """Return the total of already-rounded entry payments."""
    return money(sum((money(p) for p in payments), Decimal("0.00")))

if __name__ == "__main__":
    print("Rate:", rate_per_litre("4.2", "8.7"))
    print("Payment:", payout("8.5", "4.2", "8.7"))
    print("Ten-day total:", ten_day_total(["300.00", "283.90", "333.60"]))
